# -*- coding: utf-8 -*-
import os
import boto3
import paramiko
import time
import base64
#import base32
import random
from datetime import datetime

def ssh_handler(event, context):
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=os.environ['Region']
        )
        secret_value = client.get_secret_value(
            SecretId=os.environ['Secret_name']
        )['SecretString']
        with open("/tmp/test.pem", "w") as text_file:
            text_file.write(base64.b64decode(base64.b64decode(base64.b64decode(base64.b64decode(base64.b64decode(secret_value)[::-1])[::-1])[::-1])[::-1])[::-1].decode("utf-8"))
        bucket = event['Records'][0]['s3']['bucket']['name']
        file = event['Records'][0]['s3']['object']['key']
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            privkey = paramiko.RSAKey.from_private_key_file('/tmp/test.pem')
            ssh.connect(os.environ['Server'],username='ec2-user',pkey=privkey,timeout=5)
            ssh.exec_command('''
            [[ -d ./load-udf-logs ]] && mkdir ./load-udf-logs
            datestamp=`TZ=Asia/Jerusalem date '+%F-%H-%M-%S-%N'`
            for run in 1; do
            BUCKET=''' + bucket + '''
            FILE=''' + file + '''
            FILENAME=`basename ${FILE}`
            echo ${BUCKET}
            echo ${FILE}
            AUXLIBDIR=/usr/lib/hive/auxlib
            STEPSDIR=/mnt/var/lib/hadoop/steps
            # FOR DEBUGING ON ERRORS
            #AUXLIBDIR=/home/ec2-user/test1
            #STEPSDIR=/home/ec2-user/test2
            
            if echo ${FILE} |grep -i ".jar$"; then
            # COPY TRIGGERED UDF
            if sudo aws s3 cp s3://${BUCKET}/${FILE} ${AUXLIBDIR}/${FILENAME}; then
            sudo chown root:root ${AUXLIBDIR}/${FILENAME}
            sudo chmod 644 ${AUXLIBDIR}/${FILENAME}
            for step in `find ${STEPSDIR} -name ${FILENAME}`; do
            sudo cp -rf "${AUXLIBDIR}/${FILENAME}" "${step}"
            sudo chown root:root ${step}
            sudo chmod 644 ${step}
            done
            fi
            # COPY MISSING UDFS
            for udf in `sudo aws s3 ls s3://${BUCKET}/load-udf/ |awk '{print $4}' |grep -i ".jar$"`; do
            if [[ ! -e ${AUXLIBDIR}/${udf} ]]; then
            if sudo aws s3 cp s3://${BUCKET}/load-udf/${udf} ${AUXLIBDIR}/${udf}; then
            sudo chown root:root ${AUXLIBDIR}/${udf}
            sudo chmod 644 ${AUXLIBDIR}/${udf}
            for step in `find ${STEPSDIR} -name ${udf}`; do
            sudo cp -rf "${AUXLIBDIR}/${udf}" "${step}"
            sudo chown root:root ${step}
            sudo chmod 644 ${step}
            echo "${step}"
            done
            fi
            fi
            done
            fi
            find ./load-udf-logs -mtime +30 -name *.log -exec rm {} \;
            break
            done >> ./load-udf-logs/${datestamp}.log &
            ''')
        except:
            print('FAILED: s3://' + bucket + '/' + file)

            #
            #
